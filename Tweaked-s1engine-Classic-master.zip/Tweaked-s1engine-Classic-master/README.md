# Tweaked-s1engine (Classic server.)
A fully tweaked s1engine for the classic TERA server.

- FPS S1engine
- FPS S1engine (Normal Particle count.)

Place one of them here: TERA\Client\S1Game\Config.

__And make 100% sure they are on read only after replacing your current one.__

_You can make your file read only by right clicking the S1engine file, click on properties and then down below you'll see "Read only".
Tick that on and then apply these changes._

![Read-Only Example](https://i.imgur.com/d9kfprc.png)

__EDIT: If you do Lakan's prison, make sure to use the engine with the NORMAL particle count, it will crash your client otherwise. It's only in this dungeon.__

All of them are tweaked engines. The FPS engines are highly tweaked ones for maximum FPS. I highly recommend using the "FPS S1Engine". Do you do both PvP and PvE and your system ain't too bad, you might want to go for the normal particles one.

If you notice you don't see everything on the floor or what so ever then make sure to use the other s1engine with a higher particle count. Try what you like the most.
